import React, { createContext, useContext, useState, ReactNode } from 'react';

interface Course {
  id: string;
  title: string;
  description: string;
  instructor: string;
  duration: string;
  level: string;
  thumbnail: string;
  lessons: Lesson[];
  progress: number;
  rating: number;
  students: number;
}

interface Lesson {
  id: string;
  title: string;
  duration: string;
  videoUrl: string;
  description: string;
  completed: boolean;
  quiz?: Quiz;
}

interface Quiz {
  id: string;
  questions: Question[];
}

interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
}

interface LearningContextType {
  courses: Course[];
  currentCourse: Course | null;
  currentLesson: Lesson | null;
  setCourse: (courseId: string) => void;
  setLesson: (lessonId: string) => void;
  completeLesson: (lessonId: string) => void;
  submitQuiz: (quizId: string, answers: number[]) => number;
}

const LearningContext = createContext<LearningContextType | undefined>(undefined);

export const useLearning = () => {
  const context = useContext(LearningContext);
  if (!context) {
    throw new Error('useLearning must be used within a LearningProvider');
  }
  return context;
};

interface LearningProviderProps {
  children: ReactNode;
}

export const LearningProvider: React.FC<LearningProviderProps> = ({ children }) => {
  const [currentCourse, setCurrentCourse] = useState<Course | null>(null);
  const [currentLesson, setCurrentLesson] = useState<Lesson | null>(null);

  const mockCourses: Course[] = [
    {
      id: '1',
      title: 'React Fundamentals',
      description: 'Learn the basics of React including components, state, and props',
      instructor: 'Sarah Chen',
      duration: '8 hours',
      level: 'Beginner',
      thumbnail: 'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=800',
      progress: 65,
      rating: 4.8,
      students: 1250,
      lessons: [
        {
          id: '1',
          title: 'Introduction to React',
          duration: '15 min',
          videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
          description: 'Get started with React and understand its core concepts',
          completed: true,
          quiz: {
            id: 'q1',
            questions: [
              {
                id: 'q1-1',
                question: 'What is React?',
                options: ['A database', 'A JavaScript library', 'A CSS framework', 'A server'],
                correctAnswer: 1
              }
            ]
          }
        },
        {
          id: '2',
          title: 'Components and JSX',
          duration: '22 min',
          videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
          description: 'Learn how to create components and use JSX syntax',
          completed: true
        },
        {
          id: '3',
          title: 'State and Props',
          duration: '28 min',
          videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
          description: 'Understanding state management and component communication',
          completed: false
        }
      ]
    },
    {
      id: '2',
      title: 'Advanced JavaScript',
      description: 'Master advanced JavaScript concepts and modern ES6+ features',
      instructor: 'Mike Rodriguez',
      duration: '12 hours',
      level: 'Intermediate',
      thumbnail: 'https://images.pexels.com/photos/4164418/pexels-photo-4164418.jpeg?auto=compress&cs=tinysrgb&w=800',
      progress: 30,
      rating: 4.9,
      students: 890,
      lessons: [
        {
          id: '4',
          title: 'Async/Await and Promises',
          duration: '25 min',
          videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
          description: 'Master asynchronous JavaScript programming',
          completed: true
        },
        {
          id: '5',
          title: 'Closures and Scope',
          duration: '30 min',
          videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
          description: 'Deep dive into JavaScript closures and scope',
          completed: false
        }
      ]
    },
    {
      id: '3',
      title: 'UI/UX Design Principles',
      description: 'Learn the fundamentals of user interface and user experience design',
      instructor: 'Emma Wilson',
      duration: '6 hours',
      level: 'Beginner',
      thumbnail: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=800',
      progress: 0,
      rating: 4.7,
      students: 2100,
      lessons: [
        {
          id: '6',
          title: 'Design Thinking Process',
          duration: '20 min',
          videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4',
          description: 'Understanding the design thinking methodology',
          completed: false
        }
      ]
    }
  ];

  const [courses] = useState<Course[]>(mockCourses);

  const setCourse = (courseId: string) => {
    const course = courses.find(c => c.id === courseId);
    setCurrentCourse(course || null);
  };

  const setLesson = (lessonId: string) => {
    if (currentCourse) {
      const lesson = currentCourse.lessons.find(l => l.id === lessonId);
      setCurrentLesson(lesson || null);
    }
  };

  const completeLesson = (lessonId: string) => {
    if (currentCourse) {
      const updatedLessons = currentCourse.lessons.map(lesson =>
        lesson.id === lessonId ? { ...lesson, completed: true } : lesson
      );
      setCurrentCourse({ ...currentCourse, lessons: updatedLessons });
    }
  };

  const submitQuiz = (quizId: string, answers: number[]): number => {
    if (currentLesson?.quiz) {
      const correctAnswers = currentLesson.quiz.questions.filter(
        (question, index) => question.correctAnswer === answers[index]
      ).length;
      return (correctAnswers / currentLesson.quiz.questions.length) * 100;
    }
    return 0;
  };

  return (
    <LearningContext.Provider value={{
      courses,
      currentCourse,
      currentLesson,
      setCourse,
      setLesson,
      completeLesson,
      submitQuiz
    }}>
      {children}
    </LearningContext.Provider>
  );
};
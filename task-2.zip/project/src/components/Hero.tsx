import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ChevronDown, Github, Linkedin, Mail } from 'lucide-react';

const Hero: React.FC = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);

  useEffect(() => {
    const tl = gsap.timeline({ delay: 1 });
    
    // Animated text reveal
    if (titleRef.current) {
      const titleText = titleRef.current.textContent || '';
      titleRef.current.innerHTML = titleText
        .split('')
        .map(char => `<span class="inline-block">${char === ' ' ? '&nbsp;' : char}</span>`)
        .join('');
      
      tl.fromTo(titleRef.current.children,
        { y: 100, opacity: 0, rotationX: 90 },
        { y: 0, opacity: 1, rotationX: 0, duration: 0.8, stagger: 0.02, ease: 'back.out(1.7)' }
      );
    }

    tl.fromTo(subtitleRef.current,
      { y: 50, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.8, ease: 'power2.out' }, '-=0.5'
    )
    .fromTo('.hero-cta',
      { y: 30, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.6, stagger: 0.1 }, '-=0.3'
    )
    .fromTo('.social-links',
      { scale: 0, opacity: 0 },
      { scale: 1, opacity: 1, duration: 0.5, stagger: 0.1 }, '-=0.2'
    );

    // Floating animation for the entire hero section
    gsap.to(heroRef.current, {
      y: -10,
      duration: 3,
      repeat: -1,
      yoyo: true,
      ease: 'power1.inOut'
    });

  }, []);

  const scrollToNext = () => {
    const aboutSection = document.getElementById('about');
    if (aboutSection) {
      aboutSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center px-6 py-20">
      <div ref={heroRef} className="text-center max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 
            ref={titleRef}
            className="text-4xl md:text-6xl lg:text-7xl font-bold mb-4 bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent"
          >
            Creative Developer
          </h1>
          <p 
            ref={subtitleRef}
            className="text-xl md:text-2xl text-gray-300 mb-8 max-w-2xl mx-auto leading-relaxed"
          >
            I craft beautiful digital experiences with modern web technologies, 
            bringing ideas to life through code and creativity.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
          <button className="hero-cta px-8 py-4 bg-gradient-to-r from-cyan-500 to-purple-600 text-white font-semibold rounded-lg hover:shadow-lg hover:shadow-cyan-500/25 transition-all duration-300 transform hover:scale-105">
            View My Work
          </button>
          <button className="hero-cta px-8 py-4 border-2 border-cyan-400 text-cyan-400 font-semibold rounded-lg hover:bg-cyan-400 hover:text-gray-900 transition-all duration-300">
            Get In Touch
          </button>
        </div>

        <div className="flex justify-center space-x-6 mb-12">
          <a href="#" className="social-links group">
            <div className="p-3 rounded-full bg-gray-800 hover:bg-cyan-500 transition-all duration-300 transform group-hover:scale-110">
              <Github size={24} className="text-gray-300 group-hover:text-white" />
            </div>
          </a>
          <a href="#" className="social-links group">
            <div className="p-3 rounded-full bg-gray-800 hover:bg-blue-600 transition-all duration-300 transform group-hover:scale-110">
              <Linkedin size={24} className="text-gray-300 group-hover:text-white" />
            </div>
          </a>
          <a href="#" className="social-links group">
            <div className="p-3 rounded-full bg-gray-800 hover:bg-purple-600 transition-all duration-300 transform group-hover:scale-110">
              <Mail size={24} className="text-gray-300 group-hover:text-white" />
            </div>
          </a>
        </div>

        <button 
          onClick={scrollToNext}
          className="animate-bounce text-cyan-400 hover:text-cyan-300 transition-colors duration-300"
        >
          <ChevronDown size={32} />
        </button>
      </div>
    </section>
  );
};

export default Hero;
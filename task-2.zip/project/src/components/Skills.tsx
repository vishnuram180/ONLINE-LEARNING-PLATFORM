import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

const Skills: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const skillsData = [
    { name: 'React/Next.js', level: 95, color: 'from-blue-400 to-blue-600' },
    { name: 'TypeScript', level: 90, color: 'from-blue-500 to-indigo-600' },
    { name: 'Node.js', level: 85, color: 'from-green-400 to-green-600' },
    { name: 'Python', level: 80, color: 'from-yellow-400 to-orange-500' },
    { name: 'Three.js/WebGL', level: 75, color: 'from-purple-400 to-pink-500' },
    { name: 'GSAP/Animations', level: 90, color: 'from-cyan-400 to-teal-500' },
    { name: 'UI/UX Design', level: 85, color: 'from-pink-400 to-rose-500' },
    { name: 'Cloud/DevOps', level: 70, color: 'from-gray-400 to-gray-600' },
  ];

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    gsap.fromTo('.skills-title',
      { y: 50, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 0.8,
        scrollTrigger: {
          trigger: section,
          start: 'top 80%',
        }
      }
    );

    gsap.fromTo('.skill-item',
      { x: -50, opacity: 0 },
      {
        x: 0,
        opacity: 1,
        duration: 0.6,
        stagger: 0.1,
        scrollTrigger: {
          trigger: section,
          start: 'top 70%',
        }
      }
    );

    // Animate skill bars
    gsap.fromTo('.skill-bar-fill',
      { width: '0%' },
      {
        width: (index) => `${skillsData[index].level}%`,
        duration: 1.5,
        ease: 'power2.out',
        stagger: 0.1,
        scrollTrigger: {
          trigger: section,
          start: 'top 60%',
        }
      }
    );

    // Animate percentage counters
    skillsData.forEach((skill, index) => {
      gsap.fromTo(`.skill-percentage-${index}`,
        { textContent: '0' },
        {
          textContent: skill.level,
          duration: 1.5,
          ease: 'power2.out',
          snap: { textContent: 1 },
          scrollTrigger: {
            trigger: section,
            start: 'top 60%',
          }
        }
      );
    });

  }, [skillsData]);

  return (
    <section ref={sectionRef} id="skills" className="py-20 px-6 bg-gray-800/30">
      <div className="container mx-auto max-w-4xl">
        <h2 className="skills-title text-4xl md:text-5xl font-bold text-center mb-16 bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
          Skills & Expertise
        </h2>

        <div className="grid gap-6">
          {skillsData.map((skill, index) => (
            <div key={skill.name} className="skill-item">
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-lg font-semibold text-white">{skill.name}</h3>
                <span className="text-cyan-400 font-mono">
                  <span className={`skill-percentage-${index}`}>0</span>%
                </span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-3 overflow-hidden">
                <div 
                  className={`skill-bar-fill h-full bg-gradient-to-r ${skill.color} rounded-full relative`}
                  style={{ width: '0%' }}
                >
                  <div className="absolute right-0 top-0 w-2 h-full bg-white/30 rounded-full animate-pulse"></div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 grid md:grid-cols-2 gap-8">
          <div className="skill-item">
            <h3 className="text-2xl font-semibold mb-6 text-center text-white">Frontend</h3>
            <div className="flex flex-wrap gap-3 justify-center">
              {['React', 'Vue.js', 'TypeScript', 'Tailwind CSS', 'GSAP', 'Three.js'].map((tech) => (
                <span key={tech} className="px-4 py-2 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 backdrop-blur-sm rounded-full text-sm text-cyan-300 border border-cyan-500/30">
                  {tech}
                </span>
              ))}
            </div>
          </div>

          <div className="skill-item">
            <h3 className="text-2xl font-semibold mb-6 text-center text-white">Backend</h3>
            <div className="flex flex-wrap gap-3 justify-center">
              {['Node.js', 'Python', 'PostgreSQL', 'MongoDB', 'AWS', 'Docker'].map((tech) => (
                <span key={tech} className="px-4 py-2 bg-gradient-to-r from-purple-500/20 to-pink-500/20 backdrop-blur-sm rounded-full text-sm text-purple-300 border border-purple-500/30">
                  {tech}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;
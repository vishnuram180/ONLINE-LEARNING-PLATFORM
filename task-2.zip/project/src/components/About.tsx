import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Code, Palette, Zap } from 'lucide-react';

const About: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    gsap.fromTo('.about-title',
      { y: 50, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 0.8,
        scrollTrigger: {
          trigger: section,
          start: 'top 80%',
          end: 'bottom 20%',
        }
      }
    );

    gsap.fromTo('.about-content',
      { y: 30, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 0.6,
        stagger: 0.2,
        scrollTrigger: {
          trigger: section,
          start: 'top 70%',
          end: 'bottom 20%',
        }
      }
    );

    gsap.fromTo('.about-card',
      { scale: 0.8, opacity: 0 },
      {
        scale: 1,
        opacity: 1,
        duration: 0.6,
        stagger: 0.2,
        scrollTrigger: {
          trigger: section,
          start: 'top 60%',
          end: 'bottom 20%',
        }
      }
    );
  }, []);

  return (
    <section ref={sectionRef} id="about" className="py-20 px-6">
      <div className="container mx-auto max-w-6xl">
        <h2 className="about-title text-4xl md:text-5xl font-bold text-center mb-16 bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
          About Me
        </h2>

        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <p className="about-content text-lg text-gray-300 leading-relaxed mb-6">
              I'm a passionate developer with over 5 years of experience creating 
              exceptional digital experiences. My journey began with a fascination 
              for combining creativity with technology.
            </p>
            <p className="about-content text-lg text-gray-300 leading-relaxed mb-6">
              I specialize in modern web technologies and love bringing innovative 
              ideas to life through clean, efficient code and stunning visual design.
            </p>
            <p className="about-content text-lg text-gray-300 leading-relaxed">
              When I'm not coding, you'll find me exploring new technologies, 
              contributing to open source projects, or mentoring aspiring developers.
            </p>
          </div>

          <div className="about-content">
            <div className="relative">
              <div className="w-80 h-80 mx-auto rounded-full bg-gradient-to-br from-cyan-400 to-purple-600 p-1">
                <div className="w-full h-full rounded-full bg-gray-900 flex items-center justify-center">
                  <div className="text-6xl">👨‍💻</div>
                </div>
              </div>
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-cyan-400 rounded-full opacity-20 animate-pulse"></div>
              <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-purple-500 rounded-full opacity-20 animate-pulse" style={{ animationDelay: '1s' }}></div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="about-card group">
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-8 text-center hover:bg-gray-800/70 transition-all duration-300 transform group-hover:scale-105">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-cyan-500/20 rounded-full mb-6 group-hover:bg-cyan-500/30 transition-colors duration-300">
                <Code className="w-8 h-8 text-cyan-400" />
              </div>
              <h3 className="text-xl font-semibold mb-4 text-white">Clean Code</h3>
              <p className="text-gray-300">
                Writing maintainable, scalable, and efficient code that stands the test of time.
              </p>
            </div>
          </div>

          <div className="about-card group">
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-8 text-center hover:bg-gray-800/70 transition-all duration-300 transform group-hover:scale-105">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-purple-500/20 rounded-full mb-6 group-hover:bg-purple-500/30 transition-colors duration-300">
                <Palette className="w-8 h-8 text-purple-400" />
              </div>
              <h3 className="text-xl font-semibold mb-4 text-white">Creative Design</h3>
              <p className="text-gray-300">
                Crafting visually stunning interfaces that provide exceptional user experiences.
              </p>
            </div>
          </div>

          <div className="about-card group">
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-8 text-center hover:bg-gray-800/70 transition-all duration-300 transform group-hover:scale-105">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-pink-500/20 rounded-full mb-6 group-hover:bg-pink-500/30 transition-colors duration-300">
                <Zap className="w-8 h-8 text-pink-400" />
              </div>
              <h3 className="text-xl font-semibold mb-4 text-white">Performance</h3>
              <p className="text-gray-300">
                Optimizing applications for speed, accessibility, and seamless user interactions.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
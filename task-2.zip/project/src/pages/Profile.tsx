import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Mail, Calendar, Award, BookOpen, Clock, Edit2, Save, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLearning } from '../context/LearningContext';

const Profile: React.FC = () => {
  const { user } = useAuth();
  const { courses } = useLearning();
  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState(user?.name || '');

  if (!user) return null;

  const enrolledCourses = courses.filter(course => 
    user.enrolledCourses.includes(course.id)
  );

  const totalLearningHours = enrolledCourses.reduce((total, course) => {
    return total + parseFloat(course.duration.replace(' hours', ''));
  }, 0);

  const achievements = [
    { id: 1, title: 'First Course', description: 'Enrolled in your first course', earned: true },
    { id: 2, title: 'Quick Learner', description: 'Completed 5 lessons in one day', earned: true },
    { id: 3, title: 'Dedicated Student', description: 'Studied for 10 hours', earned: totalLearningHours >= 10 },
    { id: 4, title: 'Course Completer', description: 'Completed your first course', earned: false },
  ];

  const handleSave = () => {
    // In a real app, this would update the user profile
    setIsEditing(false);
  };

  return (
    <div className="min-h-screen p-6">
      <div className="container mx-auto max-w-4xl">
        {/* Profile Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20 mb-8"
        >
          <div className="flex items-center space-x-6">
            <div className="relative">
              <img
                src={user.avatar}
                alt={user.name}
                className="w-24 h-24 rounded-full object-cover border-4 border-white/20"
              />
              <button className="absolute bottom-0 right-0 p-2 bg-blue-500 rounded-full hover:bg-blue-600 transition-colors duration-200">
                <Edit2 className="w-4 h-4 text-white" />
              </button>
            </div>
            
            <div className="flex-1">
              <div className="flex items-center space-x-4 mb-2">
                {isEditing ? (
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={editedName}
                      onChange={(e) => setEditedName(e.target.value)}
                      className="text-2xl font-bold bg-white/10 border border-white/20 rounded-lg px-3 py-1 text-white"
                    />
                    <button
                      onClick={handleSave}
                      className="p-2 bg-green-500 rounded-lg hover:bg-green-600 transition-colors duration-200"
                    >
                      <Save className="w-4 h-4 text-white" />
                    </button>
                    <button
                      onClick={() => setIsEditing(false)}
                      className="p-2 bg-red-500 rounded-lg hover:bg-red-600 transition-colors duration-200"
                    >
                      <X className="w-4 h-4 text-white" />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center space-x-4">
                    <h1 className="text-3xl font-bold text-white">{user.name}</h1>
                    <button
                      onClick={() => setIsEditing(true)}
                      className="p-2 bg-white/10 rounded-lg hover:bg-white/20 transition-colors duration-200"
                    >
                      <Edit2 className="w-4 h-4 text-white" />
                    </button>
                  </div>
                )}
              </div>
              
              <div className="flex items-center space-x-6 text-white/70">
                <div className="flex items-center space-x-2">
                  <Mail className="w-4 h-4" />
                  <span>{user.email}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4" />
                  <span>Joined December 2023</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
        >
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-blue-500/20 rounded-lg">
                <BookOpen className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <p className="text-white/70 text-sm">Enrolled Courses</p>
                <p className="text-2xl font-bold text-white">{enrolledCourses.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-green-500/20 rounded-lg">
                <Award className="w-6 h-6 text-green-400" />
              </div>
              <div>
                <p className="text-white/70 text-sm">Completed Lessons</p>
                <p className="text-2xl font-bold text-white">{user.completedLessons.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-purple-500/20 rounded-lg">
                <Clock className="w-6 h-6 text-purple-400" />
              </div>
              <div>
                <p className="text-white/70 text-sm">Learning Hours</p>
                <p className="text-2xl font-bold text-white">{totalLearningHours.toFixed(1)}</p>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Enrolled Courses */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20"
          >
            <h2 className="text-xl font-bold text-white mb-6">My Courses</h2>
            <div className="space-y-4">
              {enrolledCourses.map((course) => (
                <div key={course.id} className="bg-white/5 rounded-lg p-4">
                  <div className="flex items-center space-x-4">
                    <img
                      src={course.thumbnail}
                      alt={course.title}
                      className="w-16 h-16 rounded-lg object-cover"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold text-white">{course.title}</h3>
                      <p className="text-white/70 text-sm">{course.instructor}</p>
                      <div className="mt-2">
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-white/70">Progress</span>
                          <span className="text-white">{course.progress}%</span>
                        </div>
                        <div className="w-full bg-white/20 rounded-full h-2">
                          <div
                            className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full"
                            style={{ width: `${course.progress}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Achievements */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20"
          >
            <h2 className="text-xl font-bold text-white mb-6">Achievements</h2>
            <div className="space-y-4">
              {achievements.map((achievement) => (
                <div
                  key={achievement.id}
                  className={`p-4 rounded-lg border ${
                    achievement.earned
                      ? 'bg-yellow-500/20 border-yellow-500/30'
                      : 'bg-white/5 border-white/10'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <Award
                      className={`w-6 h-6 ${
                        achievement.earned ? 'text-yellow-400' : 'text-white/40'
                      }`}
                    />
                    <div>
                      <h3
                        className={`font-semibold ${
                          achievement.earned ? 'text-yellow-300' : 'text-white/60'
                        }`}
                      >
                        {achievement.title}
                      </h3>
                      <p
                        className={`text-sm ${
                          achievement.earned ? 'text-yellow-200/70' : 'text-white/40'
                        }`}
                      >
                        {achievement.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
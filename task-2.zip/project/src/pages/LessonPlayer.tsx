import React, { useEffect, useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  SkipBack, 
  SkipForward,
  CheckCircle,
  ArrowLeft,
  ArrowRight
} from 'lucide-react';
import { useLearning } from '../context/LearningContext';
import { useAuth } from '../context/AuthContext';
import QuizComponent from '../components/QuizComponent';

const LessonPlayer: React.FC = () => {
  const { lessonId } = useParams<{ lessonId: string }>();
  const navigate = useNavigate();
  const { currentCourse, setLesson, currentLesson, completeLesson } = useLearning();
  const { updateProgress } = useAuth();
  const videoRef = useRef<HTMLVideoElement>(null);
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [showControls, setShowControls] = useState(true);
  const [showQuiz, setShowQuiz] = useState(false);
  const [lessonCompleted, setLessonCompleted] = useState(false);

  useEffect(() => {
    if (lessonId) {
      setLesson(lessonId);
    }
  }, [lessonId, setLesson]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleTimeUpdate = () => setCurrentTime(video.currentTime);
    const handleDurationChange = () => setDuration(video.duration);
    const handleEnded = () => {
      setIsPlaying(false);
      if (currentLesson && !lessonCompleted) {
        completeLesson(currentLesson.id);
        updateProgress(currentLesson.id);
        setLessonCompleted(true);
        
        if (currentLesson.quiz) {
          setShowQuiz(true);
        }
      }
    };

    video.addEventListener('timeupdate', handleTimeUpdate);
    video.addEventListener('durationchange', handleDurationChange);
    video.addEventListener('ended', handleEnded);

    return () => {
      video.removeEventListener('timeupdate', handleTimeUpdate);
      video.removeEventListener('durationchange', handleDurationChange);
      video.removeEventListener('ended', handleEnded);
    };
  }, [currentLesson, completeLesson, updateProgress, lessonCompleted]);

  if (!currentCourse || !currentLesson) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-white text-xl">Lesson not found</div>
      </div>
    );
  }

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;

    if (isPlaying) {
      video.pause();
    } else {
      video.play();
    }
    setIsPlaying(!isPlaying);
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;

    video.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const video = videoRef.current;
    if (!video) return;

    const newTime = (parseFloat(e.target.value) / 100) * duration;
    video.currentTime = newTime;
    setCurrentTime(newTime);
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const currentLessonIndex = currentCourse.lessons.findIndex(l => l.id === currentLesson.id);
  const nextLesson = currentCourse.lessons[currentLessonIndex + 1];
  const prevLesson = currentCourse.lessons[currentLessonIndex - 1];

  const navigateToLesson = (lesson: any) => {
    navigate(`/lesson/${lesson.id}`);
  };

  return (
    <div className="min-h-screen bg-black">
      {showQuiz && currentLesson.quiz ? (
        <QuizComponent
          quiz={currentLesson.quiz}
          onComplete={() => setShowQuiz(false)}
        />
      ) : (
        <div className="flex flex-col lg:flex-row h-screen">
          {/* Video Player */}
          <div className="flex-1 relative bg-black">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="relative h-full"
              onMouseEnter={() => setShowControls(true)}
              onMouseLeave={() => setShowControls(false)}
            >
              <video
                ref={videoRef}
                src={currentLesson.videoUrl}
                className="w-full h-full object-contain"
                onClick={togglePlay}
              />

              {/* Video Controls Overlay */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: showControls ? 1 : 0 }}
                className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/60 flex flex-col justify-between p-6"
              >
                {/* Top Controls */}
                <div className="flex items-center justify-between">
                  <button
                    onClick={() => navigate(`/course/${currentCourse.id}`)}
                    className="flex items-center space-x-2 px-4 py-2 bg-black/50 backdrop-blur-sm rounded-lg text-white hover:bg-black/70 transition-colors duration-200"
                  >
                    <ArrowLeft className="w-5 h-5" />
                    <span>Back to Course</span>
                  </button>
                  
                  <div className="text-white text-center">
                    <h1 className="text-xl font-semibold">{currentLesson.title}</h1>
                    <p className="text-white/70">{currentCourse.title}</p>
                  </div>
                  
                  <div className="w-32" /> {/* Spacer */}
                </div>

                {/* Center Play Button */}
                <div className="flex items-center justify-center">
                  <button
                    onClick={togglePlay}
                    className="p-4 bg-white/20 backdrop-blur-sm rounded-full hover:bg-white/30 transition-colors duration-200"
                  >
                    {isPlaying ? (
                      <Pause className="w-12 h-12 text-white" />
                    ) : (
                      <Play className="w-12 h-12 text-white ml-1" />
                    )}
                  </button>
                </div>

                {/* Bottom Controls */}
                <div className="space-y-4">
                  {/* Progress Bar */}
                  <div className="flex items-center space-x-4">
                    <span className="text-white text-sm font-mono">
                      {formatTime(currentTime)}
                    </span>
                    <div className="flex-1">
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={duration ? (currentTime / duration) * 100 : 0}
                        onChange={handleSeek}
                        className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer slider"
                      />
                    </div>
                    <span className="text-white text-sm font-mono">
                      {formatTime(duration)}
                    </span>
                  </div>

                  {/* Control Buttons */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <button
                        onClick={togglePlay}
                        className="p-2 hover:bg-white/20 rounded-lg transition-colors duration-200"
                      >
                        {isPlaying ? (
                          <Pause className="w-6 h-6 text-white" />
                        ) : (
                          <Play className="w-6 h-6 text-white" />
                        )}
                      </button>
                      
                      <button
                        onClick={toggleMute}
                        className="p-2 hover:bg-white/20 rounded-lg transition-colors duration-200"
                      >
                        {isMuted ? (
                          <VolumeX className="w-6 h-6 text-white" />
                        ) : (
                          <Volume2 className="w-6 h-6 text-white" />
                        )}
                      </button>
                    </div>

                    <div className="flex items-center space-x-2">
                      {prevLesson && (
                        <button
                          onClick={() => navigateToLesson(prevLesson)}
                          className="flex items-center space-x-1 px-3 py-2 bg-white/20 backdrop-blur-sm rounded-lg text-white hover:bg-white/30 transition-colors duration-200"
                        >
                          <SkipBack className="w-4 h-4" />
                          <span className="text-sm">Previous</span>
                        </button>
                      )}
                      
                      {nextLesson && (
                        <button
                          onClick={() => navigateToLesson(nextLesson)}
                          className="flex items-center space-x-1 px-3 py-2 bg-white/20 backdrop-blur-sm rounded-lg text-white hover:bg-white/30 transition-colors duration-200"
                        >
                          <span className="text-sm">Next</span>
                          <SkipForward className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    <button className="p-2 hover:bg-white/20 rounded-lg transition-colors duration-200">
                      <Maximize className="w-6 h-6 text-white" />
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>

          {/* Lesson Info Sidebar */}
          <motion.div
            initial={{ x: 300, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            className="w-full lg:w-96 bg-gray-900 border-l border-gray-800 overflow-y-auto"
          >
            <div className="p-6">
              <div className="mb-6">
                <h2 className="text-2xl font-bold text-white mb-2">{currentLesson.title}</h2>
                <p className="text-gray-300 leading-relaxed">{currentLesson.description}</p>
              </div>

              {lessonCompleted && (
                <motion.div
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="mb-6 p-4 bg-green-500/20 border border-green-500/30 rounded-lg"
                >
                  <div className="flex items-center space-x-2 text-green-400">
                    <CheckCircle className="w-5 h-5" />
                    <span className="font-medium">Lesson Completed!</span>
                  </div>
                </motion.div>
              )}

              {currentLesson.quiz && (
                <button
                  onClick={() => setShowQuiz(true)}
                  className="w-full mb-6 p-4 bg-purple-500/20 border border-purple-500/30 rounded-lg text-purple-300 hover:bg-purple-500/30 transition-colors duration-200"
                >
                  Take Quiz
                </button>
              )}

              {/* Course Lessons List */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">Course Lessons</h3>
                <div className="space-y-2">
                  {currentCourse.lessons.map((lesson, index) => (
                    <button
                      key={lesson.id}
                      onClick={() => navigateToLesson(lesson)}
                      className={`w-full p-3 rounded-lg text-left transition-colors duration-200 ${
                        lesson.id === currentLesson.id
                          ? 'bg-blue-500/20 border border-blue-500/30'
                          : 'bg-gray-800 hover:bg-gray-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <h4 className={`font-medium ${
                            lesson.id === currentLesson.id ? 'text-blue-300' : 'text-white'
                          }`}>
                            {lesson.title}
                          </h4>
                          <p className="text-gray-400 text-sm">{lesson.duration}</p>
                        </div>
                        {lesson.completed && (
                          <CheckCircle className="w-5 h-5 text-green-400" />
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default LessonPlayer;
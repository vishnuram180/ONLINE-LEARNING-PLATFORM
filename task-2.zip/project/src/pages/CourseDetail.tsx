import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { useParams, Link } from 'react-router-dom';
import { Play, Clock, Users, Star, CheckCircle, Lock, BookOpen } from 'lucide-react';
import { useLearning } from '../context/LearningContext';
import { useAuth } from '../context/AuthContext';

const CourseDetail: React.FC = () => {
  const { courseId } = useParams<{ courseId: string }>();
  const { courses, setCourse, currentCourse } = useLearning();
  const { user } = useAuth();

  useEffect(() => {
    if (courseId) {
      setCourse(courseId);
    }
  }, [courseId, setCourse]);

  if (!currentCourse) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-white text-xl">Course not found</div>
      </div>
    );
  }

  const isEnrolled = user?.enrolledCourses.includes(currentCourse.id);
  const completedLessons = currentCourse.lessons.filter(lesson => 
    user?.completedLessons.includes(lesson.id)
  ).length;

  return (
    <div className="min-h-screen p-6">
      <div className="container mx-auto max-w-6xl">
        {/* Course Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-md rounded-2xl overflow-hidden border border-white/20 mb-8"
        >
          <div className="grid lg:grid-cols-2 gap-8 p-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <span className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-sm">
                  {currentCourse.level}
                </span>
                <div className="flex items-center space-x-1 text-yellow-400">
                  <Star className="w-4 h-4 fill-current" />
                  <span className="text-white text-sm">{currentCourse.rating}</span>
                </div>
              </div>
              
              <h1 className="text-4xl font-bold text-white mb-4">
                {currentCourse.title}
              </h1>
              
              <p className="text-white/70 text-lg mb-6 leading-relaxed">
                {currentCourse.description}
              </p>
              
              <div className="flex items-center space-x-6 text-white/60 mb-6">
                <div className="flex items-center space-x-2">
                  <Clock className="w-5 h-5" />
                  <span>{currentCourse.duration}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users className="w-5 h-5" />
                  <span>{currentCourse.students} students</span>
                </div>
                <div className="flex items-center space-x-2">
                  <BookOpen className="w-5 h-5" />
                  <span>{currentCourse.lessons.length} lessons</span>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                {isEnrolled ? (
                  <Link
                    to={`/lesson/${currentCourse.lessons[0].id}`}
                    className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold rounded-lg hover:shadow-lg hover:shadow-blue-500/25 transition-all duration-200"
                  >
                    <Play className="w-5 h-5" />
                    <span>Continue Learning</span>
                  </Link>
                ) : (
                  <button className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white font-semibold rounded-lg hover:shadow-lg hover:shadow-green-500/25 transition-all duration-200">
                    <span>Enroll Now</span>
                  </button>
                )}
              </div>
            </div>

            <div className="relative">
              <img
                src={currentCourse.thumbnail}
                alt={currentCourse.title}
                className="w-full h-80 object-cover rounded-xl"
              />
              <div className="absolute inset-0 bg-black/40 rounded-xl flex items-center justify-center">
                <button className="p-4 bg-white/20 backdrop-blur-sm rounded-full hover:bg-white/30 transition-colors duration-200">
                  <Play className="w-8 h-8 text-white" />
                </button>
              </div>
            </div>
          </div>

          {isEnrolled && (
            <div className="px-8 pb-8">
              <div className="bg-white/5 rounded-xl p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-xl font-semibold text-white">Your Progress</h3>
                  <span className="text-2xl font-bold text-white">{currentCourse.progress}%</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-3 mb-4">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${currentCourse.progress}%` }}
                    transition={{ duration: 1, delay: 0.5 }}
                    className="bg-gradient-to-r from-blue-500 to-purple-600 h-3 rounded-full"
                  />
                </div>
                <p className="text-white/70">
                  {completedLessons} of {currentCourse.lessons.length} lessons completed
                </p>
              </div>
            </div>
          )}
        </motion.div>

        {/* Course Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20"
        >
          <h2 className="text-2xl font-bold text-white mb-6">Course Content</h2>
          
          <div className="space-y-4">
            {currentCourse.lessons.map((lesson, index) => {
              const isCompleted = user?.completedLessons.includes(lesson.id);
              const isAccessible = isEnrolled && (index === 0 || user?.completedLessons.includes(currentCourse.lessons[index - 1]?.id));
              
              return (
                <motion.div
                  key={lesson.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 * index }}
                  className={`group ${isAccessible ? 'cursor-pointer' : 'cursor-not-allowed'}`}
                >
                  <Link
                    to={isAccessible ? `/lesson/${lesson.id}` : '#'}
                    className={`block p-6 rounded-xl border transition-all duration-200 ${
                      isAccessible
                        ? 'bg-white/5 border-white/20 hover:bg-white/10 hover:border-white/30'
                        : 'bg-white/5 border-white/10 opacity-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className={`p-3 rounded-lg ${
                          isCompleted
                            ? 'bg-green-500/20 text-green-400'
                            : isAccessible
                            ? 'bg-blue-500/20 text-blue-400'
                            : 'bg-gray-500/20 text-gray-400'
                        }`}>
                          {isCompleted ? (
                            <CheckCircle className="w-6 h-6" />
                          ) : isAccessible ? (
                            <Play className="w-6 h-6" />
                          ) : (
                            <Lock className="w-6 h-6" />
                          )}
                        </div>
                        <div>
                          <h3 className={`text-lg font-semibold ${
                            isAccessible ? 'text-white group-hover:text-blue-300' : 'text-white/50'
                          } transition-colors duration-200`}>
                            {lesson.title}
                          </h3>
                          <p className={`text-sm ${
                            isAccessible ? 'text-white/70' : 'text-white/40'
                          }`}>
                            {lesson.description}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-1 text-white/60">
                          <Clock className="w-4 h-4" />
                          <span className="text-sm">{lesson.duration}</span>
                        </div>
                        {lesson.quiz && (
                          <span className="px-2 py-1 bg-purple-500/20 text-purple-300 rounded text-xs">
                            Quiz
                          </span>
                        )}
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default CourseDetail;